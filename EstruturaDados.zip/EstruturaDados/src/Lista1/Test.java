package Lista1;

public class Test {

	public static void main(String[] args) {
		
		Exercicio1 p = new Exercicio1();
		p.INTERSECCAO();
	}

}
