package ListaRP;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		System.out.println(horas(1));
	}
	
	
	// 1) Escreva uma fun��o que imprime a frase �Meu primeiro c�digo em java
	
	static public String palavra(String x) {
		
		// coloque no MAIN: System.out.println(palavra("meu primeiro codigo em java"));
		
		String palavra=x;
		
		return palavra;
	}
	
	
	
	//2) Escreva uma fun��o que receba como par�matro dois n�meros inteiros 
	//e retorne a soma dos mesmos. 
	
	
	static public int soma(int x, int y) {
	
		//System.out.println(soma(2,5));
		
		
		int soma = x+y;
		
		return soma;
	}

	
	
	//3) Escreva uma fun��o que imprime os n�meros de 1 at� 10.

	static public void mostraN() {
		
		for(int i=0;i<10;i++){
	     
	System.out.println(i+1);
		}
		
	}

	
	
	//4) Escreva uma fun��o que receba como par�metro um numero 
	//inteiro A e outro n�mero inteiro B e calcule A elevado a pot�ncia de B. 
	
	static public int elevacao(int a, int b) {
		
		//System.out.println(elevacao(2,2));
		
		int elevacao=(int) Math.pow(a, b);
	
	return elevacao;
	}



	//7) Escreva um c�digo que recebe a idade de uma pessoa 
	//e imprima se a mesma j� tem o direito de poder votar. 

	static public boolean podevotar(int x) {
		//System.out.println(podevotar(18));
		
		boolean podevotar=false;
		
		if(x>=16) {
			return podevotar=true;
		}
		return podevotar;
		
				
	}



	
	//10) c)

	
	
	static public  String mudarNome(String Nantigo, String trocarpor) {
		String mudado;
	//System.out.println(mudarNome("luccas","joao"));
		
		
		Nantigo=trocarpor;
		mudado=trocarpor;
		System.out.println("seu nome foi atualizado para:");
		return mudado;
		
	}




   //11)Escreva uma fun��o que recebe como par�metro um vetor de ta  		manho 10 
	//e imprima todos os valores. 

	
	public static void mostraVetor(int v[]) {
	
		//COLAR NO MAIN:
		
		//int a[]= {1,2,3,4,5,6,7,8,9,10};
		//mostraVetor(a);
		
		for(int i=0;i<=v[i];i++) {
			
			System.out.println(v[i]);
		}
		
	}

//	12)Escreva uma fun��o que recebe como par�metro um vetor de tamanho 10 
	//e retorne a soma do mesmo. 

	
	public static int SomaVetor(int v[], int tamanho) {
		//COLA ESSA MERDA NO MAIN::: System.out.println(SomaVetor(null, 10));
		
		Scanner tc = new Scanner(System.in);
		
		int soma=0;
		v= new int[tamanho];
		
		//inserindo valores para o vetor
		 for (int i = 0; i < tamanho; i++) {
	            System.out.print("Digite o " + (i + 1) + "� valor: ");
	            
	            v[i] = tc.nextInt();
		 }
		//calculo da soma
		  for (int i = 0; i < tamanho; i++) {
		       soma+= v[i];
		        }
		        
		
		return soma;
	}

//13)Escreva uma fun��o que recebe como par�metro um vetor e retorne 
//a soma dos n�meros pares deste vetor 

	public static int SomaVetorPAR(int tamanho, int v[]) {
		
		Scanner tc = new Scanner(System.in);
		int soma=0, soma1=0;
		System.out.println("tamanho do vetor?");
		
		v= new int[tamanho];
		
		for(int i =0;i<v.length;i++) {
		System.out.print("Digite o " + (i + 1) + "� valor: ");
			v[i]= tc.nextInt();
			
			
		}
		
		for(int i =0;i<v.length;i++) {
			
			if(v[i]%2==0) {
				soma+=v[i];
			
			
			}else 
				soma1+=v[i];
		}
	
	
		return soma;
	} 
		
		
//15)Escreva uma fun��o que recebe como par�metro um vetor e 
//retorne um outro vetor apenas com os n�meros pares do vetor passado por par�metro

	public static int novoVetorPar(int v[]) {
   // botar main;
		
		int a[]= {1,2,3,4,5,6,7,8,9,10};
		
		novoVetorPar(a);
		
		int tamanho =v.length, n=tamanho/2;
		
		int aux=0;
		
		int novo[]= new int [n];
		
		
		for(int i=0; i<=tamanho;i++) {
			if(v[i]%2==0);
				aux++;
			
			
		}
			
			
		
		
		return 0;
	}

	
	
	
	public static int Maiorn(int v[]){
		
		//int a []={1,2,3,4,5,6,7};
		//Maiorn(a);
		
		int max=v[0];
		
		for(int i=0;i<v.length;i++) {
			
			if(v[i]>max) {
				
				max=v[i];
				return max;
			}return 0;
			}
				return 1;
		}
		
		
	
	public static void horas(int z) {
		
		System.out.println("Hora informada: "+ z + " \n Segundos: "+ (z*3600) + " minutos: " + (z*60));
		
	}
	
	}













