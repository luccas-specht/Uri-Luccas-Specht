package ListaRP;

import java.util.Scanner;

public class MainG {

	
	public static void main(String[] args) {
		Gato o = new Gato();
		
	System.out.println(o.miar());
	


		
	}
		
		
		
		
	}

