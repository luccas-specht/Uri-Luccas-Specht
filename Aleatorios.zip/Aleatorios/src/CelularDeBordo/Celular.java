package CelularDeBordo;

import java.util.Scanner;

public class Celular {
	
	

	public static void main(String[] args) {
		
	Calculadora x= new Calculadora();
	
	 
	
	 System.out.print(x.SOMA());
	
	
	
//    System.err.printf("\n\n\t\t CELULAR DE BORDO\n\n\n");
//    System.err.printf("\b\n\b\n\b\n\b\n\b\n\b\n\b\n\b");
//    System.err.printf("\b\b\b\b\b\b\b\b");
//    System.err.printf(".\b.\b.\b.\b.\b.\b.\b.\b");
//		
	
	
	
	
	
		

	}

}
