package fila;

import java.io.*;
import java.util.*;




	//jogando cartas fora

class Main  {
    public static void main(String[] args) throws NumberFormatException, IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        
        int qteCartas = leitor(br);
        
        while (qteCartas != 0) {
            ArrayList<Integer> pilha = new ArrayList<Integer>();

            insere(qteCartas, pilha);

            bw.write("Discarded cards: ");

            
            int topo = 0;
            while (qteCartas > 1) {
                if (topo > 0) {
                    bw.write(", ");
                }
                bw.write(String.valueOf(pilha.get(topo)));
                topo++; // simula uma remo��o da pilha
                qteCartas--; // por remover uma carta
                realoca(topo, pilha); // coloca a carta no topo na base
                topo++; // considera a proxima carta
            }
            
           
            
            
            bw.newLine();
            bw.write("Remaining card: " + String.valueOf(pilha.get(topo)));
            bw.newLine();
            
            qteCartas = leitor(br);
        }

        bw.flush();        
        bw.close();
    }

    
    
    
   public static void insere(int qte, ArrayList<Integer> pilha) {
        for (int i = 0; i < qte; i++) {
            pilha.add(i+1);
        }
    }
    
    
    
    
    
    
    
    public static void realoca(int topo, ArrayList<Integer> pilha) {
        int carta = pilha.get(topo);       
        pilha.add(carta);
    }
        
    
    
    
    
    
    
    
    
    
    
    
   public static int leitor(BufferedReader br) throws NumberFormatException, IOException {
       int n;
       int resp = 0;
       int sinal = 1;
       while (true) {
           n = br.read();
           if (n >= '0' && n <= '9') break;
           if (n == '-') sinal = -1;
           if (n == '+') sinal = 1;
       }
       while (true) {
           resp = resp*10 + n-'0';
           n = br.read();
           if (n < '0' || n > '9') break;
       }

       return resp*sinal;
    }
}
