package Lista;

public class Main2 {

	public static void main(String[] args) {
		 
//		-AAN
//		aan.setProximo(ana)
//		ana.setAnterior(aan)
//		aan<----->ana<--->bruna<--->carlos<-->daniela<-->ester<--->henrique
//		--CARLA
//		carla.setProximo(aan.getProximo().getProximo().getProximo())
//		carla.setAnterior(aan.getProximo().getProximo())
//		carla.getAnterior().setProximo(carla)
//		carla.getProximo().setAnterior(carla)
//		aan<----->ana<--->bruna<--->carla<--->carlos<-->daniela<-->ester<--->henrique
//		--TALITA
//		talita.setAnterior(henrique)
//		talita.getAnterior().setProximo(talita)
//		aan<----->ana<--->bruna<--->carla<--->carlos<-->daniela<-->ester<--->henrique<-->talita
//		--DANIELLA
//		                          ana           bruna         carla       carlos       daniela
//		daniella.setAnterior(aan.getProximo().getProximo().getProximo().getProximo().getProximo())
//		                          ana           bruna         carla       carlos       daniela    ester
//		daniella.setProximo(aan.getProximo().getProximo().getProximo().getProximo().getProximo().getProximo())
//		daniela.getAnterior().setProximo(daniela)
//		daniela.getProximo().setAnterior(daniela)
		
		//ADD TODOS
		// EXERCICO1
		
		
	}

}
