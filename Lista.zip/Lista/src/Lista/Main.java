package Lista;

public class Main {


//public static boolean existe(Pessoa inicio,String nome){
//    
//	// System.out.println(existe(hulk,"Spider")); COLA NO MAIN;
//	   
//	
////	Pessoa aux = inicio;
////   
////    while(aux != null){
////        if(aux.getNome().compareTo(nome)==0)
////            return true;
////       
////        aux = aux.getProximo();
////    }
////    return false;
//}
//
//



public static void main(String args[]){
  
	Pessoa hulk = new Pessoa("Hulk");
    Pessoa stark = new Pessoa("Stark");
    Pessoa spider = new Pessoa("Spider");
    Pessoa camerica = new Pessoa("Capitao America");
    Pessoa viuvaNegra = new Pessoa("Viuva Negra");
   
    hulk.setAnterior(null);
    hulk.setProximo(viuvaNegra);
    viuvaNegra.setAnterior(hulk);
    viuvaNegra.setProximo(camerica);
    camerica.setAnterior(viuvaNegra);
    camerica.setProximo(stark);
    stark.setAnterior(camerica);
    stark.setProximo(spider);
    spider.setAnterior(stark);
   
    
    System.out.println(hulk.getAnterior().getNome());

}
}