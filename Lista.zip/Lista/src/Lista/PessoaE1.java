package Lista;

public class PessoaE1 {

	private String nome;
	private String prox;
	private String ante;

	public PessoaE1() {
		nome=null;
		prox=null;
		ante=null;
		
	}
	
	public PessoaE1(String v1, String v2, String v3) {
		this.nome=v1;
		this.prox=v2;
		this.ante=v3;

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getProx() {
		return prox;
	}

	public void setProx(String prox) {
		this.prox = prox;
	}

	public String getAnte() {
		return ante;
	}

	public void setAnte(String ante) {
		this.ante = ante;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
