package Lista;

public class mainE2 {

	public static void main(String[] args) {
		
		PessoaE1 o= new PessoaE1();
		o.setNome("merlin");
		
		System.out.println(o.getNome());
	}

}
