package Lista;

public class Mercado {

	private String nome;
   
	private Mercado proximo;
    private Mercado anterior;
    private Mercado baixo;
    private Mercado cima;
	
	
    
    
    public x(String nome, Mercado proximo, Mercado anterior, Mercado baixo, Mercado cima) {

		this.nome = nome;
		this.proximo = proximo;
		this.anterior = anterior;
		this.baixo = baixo;
		this.cima = cima;
	}
	
}
