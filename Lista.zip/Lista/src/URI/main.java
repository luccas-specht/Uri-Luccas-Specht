package URI;

public class main {

//	public static void main(String[] args) {
//		System.out.println(Rvetor());
//	}
//
//	
//	public static int Rvetor(int v[]) {
//	
//		for(int i=0; i<v.length; i++) {
//			System.out.println(v[i]);
//			
//		}
//		
//		
//		
//		
//		return 0;	
//	}
//	

}
