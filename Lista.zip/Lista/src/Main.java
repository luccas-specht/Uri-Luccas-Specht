



public class Main {
	public static void main(String args[]){
	
	
	
	
	
	
	}
	
	
	
	
	
	public int Soma(int a,int b) {
		
		
		
		return 0;
		
	}
	
}
